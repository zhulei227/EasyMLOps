from easymlops.ocr.core.pipeline import OCRPipeLine

from easymlops.ocr.text import EasyOCRText, RapidOCRText, PaddleOCRText, PaddleOCRStructure, \
    VLDocumentParser
