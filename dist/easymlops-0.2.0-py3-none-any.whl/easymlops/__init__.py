__version__ = "0.2.0"

from .table.core import TablePipeLine
from .nlp.core import NLPPipeline
from .ts.core import TSPipeLine

import warnings

warnings.filterwarnings("ignore")
